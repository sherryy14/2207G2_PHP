<?php
$conn = mysqli_connect("localhost", "root", "", "todo_app");
